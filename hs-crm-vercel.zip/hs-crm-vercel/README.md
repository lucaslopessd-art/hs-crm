# HS CRM — Vite + React + TS

## Scripts
- `npm run dev` — ambiente local
- `npm run build` — build de produção (gera `dist/`)
- `npm run preview` — pré-visualizar o build

## Deploy
- **Vercel**: conexão Git ou `vercel` CLI (ver `vercel.json` SPA rewrite)
- **Netlify**: conexão Git ou `netlify deploy` (ver `netlify.toml` SPA redirects)
